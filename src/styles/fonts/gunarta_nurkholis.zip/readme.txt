Happy Ramadan Month and Idul Fitri 1434 H, Everybody! :D
_____________________________________

It's free for personal and commercial users. For commercial user please contact me first. Use this font wisely. Not permitted for pornographic using, sarcasm, and other negative aims.

Donation is highly appreciated!

Donation will help me to elevate my creativity and finance my school necessity. You can donate me to my paypal account maximadien@gmail.com or if you didn't have paypal account, you can donate to my bank account (Bank Mandiri, contact me for further information).

You can also donate by sending books or e-books (I'd like to read a lot), apparel, CDs, certificates, etc., especially something containing my font.

______________________________________

Twitter: @bergunarta FB: Adien Gunarta